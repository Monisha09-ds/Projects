<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home (Hotel Management)</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="img/LOGO.png" type="img/icon" rel="icon">
</head>

<body>
    <div id="full">
        <div id="bg" style="background-image: url('img/bed.jpg'); height: 1200px;">
            <div id="header">
                <div id="logo">
                    <h1>
                        <font color="white">My Project</font>
                    </h1>
                </div>
                <div id="nav">
                     <ul>
                        <li><a href="ahome.php">Home</a></li>
                        <li><a href="room.php">Room Update</a></li>
                        <li><a href="booking.php">Booking</a></li>
                        <li><a href="rd.php">Room details</a></li>
                        <li><a href="#">Help</a></li>
                    </ul>
                </div>
            </div>
            <div id="banner"><br><br><br><br><br><br><br><br><br><br>
                <h1 style="color:blue;text-align:center;">Welcome Admin</h1>
                
            </div>
        </div>
    </div>

    </div>
</body>

</html>